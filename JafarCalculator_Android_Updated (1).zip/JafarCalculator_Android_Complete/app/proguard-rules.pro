# Jafar Calculator currently uses a local WebView asset and no custom libraries.
# Keep this file for future release-build rules.
